Hi,

Here is the data in .txt files. One for each set

Format:
#Initial something name
#Initial value U0 etc.
# -- empty line --
#Oscillator something
#[Long list of values each for one step)

Show:
- E_tot, lin_mom_tot and ang_mom_tot conservation
  i.e. take each value and substract the initial value and plot to show how close to zero
  the data set follows
- If you have time, add kinetics and potential energy and momenta variance to different graphs

Note:
- This simulation used half-time step leapfrog algorithm
(Set initial positions and velocities -> Loop (Force, velocity) calculations with (Position))
- timestep was 0.000001
- total steps made 100 000
- positions and velocities were randomised
- additional parameters:
  mass_p1 = 1.0
  mass_p2 = 1.0
  r_0 = 1.0
  eq_r = 1.0
  k = 1.0


That should be everything. Its early morning and I am losing it. Good luck.